package Mojo::File::Role::Fasta;

use Mojo::Base -role, -signatures;
use Mojo::Collection 'c';
use Mojo::EventEmitter;
use Mojo::IOLoop::Stream;
use Mojo::Util 'decode';
use Carp 'croak';
use Exporter 'import';
use File::Which 'which';
use IPC::Open3 'open3';
use POSIX 'WNOHANG';
use Struct::Dumb 'readonly_struct';
use Symbol 'gensym';

our $VERSION = '0.01';

use constant GZIP_ID_SIZE => 2;
use constant GZIP_ID1     => 0x1F;
use constant GZIP_ID2     => 0x8B;
use constant GZIP_CMD     => (which('bgzip') ? 'bgzip' : 'gzip');
use constant HAS_GZIP     => (which(GZIP_CMD) ? 1 : 0);

readonly_struct FastaRecord => [qw(id seq)], predicate => "is_FastaRecord";

our @EXPORT_OK = 'is_FastaRecord';
my $intra_eol = qr/(?:\n|\r\n)/;

around open => sub ($orig, $self, $mode) {
  return $self->$orig($mode) unless ref($_) eq 'HASH';
  return $self->$orig($mode) unless $_->{is_gzip_compressed};

  croak "cannot open gzip compressed files without " . GZIP_CMD unless HAS_GZIP;
  my $fh;
  my $emitter = $_->{emitter} ||= Mojo::EventEmitter->new->tap(
    on => parse_error => sub { shift; warn "@_"; });
  $_->{stderr} = gensym;
  $_->{pid}    = eval {
    open3(undef, $fh, $_->{stderr}, GZIP_CMD, '-dc', "$self");
  };
  $emitter->emit(error => $@) && return if $@;

  # parent
  if ($_->{pid}) {
    $_->{stream} = Mojo::IOLoop::Stream->new($_->{stderr})
      ->tap(on => read => sub { shift; $emitter->emit(parse_error => @_) });
    $_->{stream}->start;
    $_->{stream}->reactor->start unless $_->{stream}->reactor->is_running;
    return $fh;
  }

  # child - required???
  POSIX::_exit(0);
};

sub is_gzip_compressed ($self) {
  !!($self =~ qr/\.b?gz$/ && _has_gzip_header($self));
}

sub parse ($self, $opts, $cb = undef) {
  $opts->{eol}                = '>';
  $opts->{is_gzip_compressed} = $self->is_gzip_compressed;

  return _readlines(_open($self, $opts), $opts, $cb) if $cb;
  return if $opts->{is_gzip_compressed} || $opts->{is_large};
  return c(split $opts->{eol} => decode $opts->{encoding} => $self->slurp)
    ->tap(sub { shift @$_ })->map(sub {
    my ($id, @seq) = split $intra_eol => $_;
    FastaRecord($id, join '' => @seq);
    });
}

sub _has_gzip_header ($self, $header = undef) {
  CORE::open(my $fh, '<', $self) || croak qq{Can't open file "$$self": $!};
  return unless GZIP_ID_SIZE == sysread($fh, $header, GZIP_ID_SIZE, 0);
  my @id = unpack('C2', $header);
  return !!(($id[0] == GZIP_ID1) && ($id[1] == 0x8B));
}

sub _open ($self, $opts, $fh = undef) {
  $fh = $self->open($opts->{mode}) for $opts;
  return $fh;
}

sub _readlines ($fh, $opts, $cb) {
  local $/ = $opts->{eol};
  my $dummy = <$fh>;
  while (readline $fh) {
    chomp;
    my ($hdr, @seq) = split $intra_eol => $_;
    $cb->($hdr, join '' => @seq);
  }
  close $fh;
  1 while ($opts->{is_gzip_compressed} && (waitpid $opts->{pid}, WNOHANG) > 0);
  $!;
}

1;

=encoding utf8

=begin html

<!-- Travis badge -->
<a href="https://travis-ci.com/kiwiroy/mojo-file-role-fasta">
  <img src="https://travis-ci.com/kiwiroy/mojo-file-role-fasta.svg?branch=master&token=Kpqpmk91fYg5k9hdqK3y"
       alt="Travis Build Status" />
</a>
<!-- Kritika badge
<a href="https://kritika.io/users/kiwiroy/repos/9231669397817641/heads/master/">
  <img src="https://kritika.io/users/kiwiroy/repos/9231669397817641/heads/master/status.svg?type=score%2Bcoverage%2Bdeps"
       alt="Kritika Analysis Status" />
</a>
-->
<!-- Coveralls badge
<a href="https://coveralls.io/github/kiwiroy/mojo-file-role-ingest?branch=master">
  <img src="https://coveralls.io/repos/github/kiwiroy/mojo-file-role-ingest/badge.svg?branch=master"
       alt="Coverage Status" />
</a>
-->

=end html

=head1 NAME

Mojo::File::Role::Fasta - Role to parse a FASTA format file

=head1 SYNOPSIS

  $file = Mojo::File->with_roles('+Ingest')->new('sequence.fa');

  # Mojo::Collection of FastaRecords
  $sequences = $file->ingest('+Fasta');

  # Callback version
  $file->ingest('+Fasta', {}, sub ($id, $seq) {
    $db->insert(sequence => {id => $id, sequence => $seq});
  });
  
  # Compressed file using callback version only.
  $file = Mojo::File->with_roles('+Ingest')->new('sequence.fa,gz');
  $file->ingest('+Fasta', {emitter => $emitter}, sub ($id, $seq) {
    $db->insert(sequence => {id => $id, sequence => $seq});
  });

=head1 DESCRIPTION

A role to parse a FASTA format file, ingesting to memory or other location.

=head1 EVENTS

During L</"parse"> Mojo::File::Role::Fasta will emit the following events on the
L<Mojo::EventEmitter>.

=head2 parse_error

  $e->on(parse_error => sub ($e, $msg) {
    say STDERR "Read error: $msg";
  });

This is exclusively emitted when a compressed file is being read and there is an
error parsing due to C<gzip> errors.

=head1 METHODS

L<Mojo::File::Role::Fasta> implements L<Mojo::File::Role::IngestI> and as such
composes the following methods.

=head2 is_gzip_compressed

A B<readonly> Boolean to flag whether the file is compressed using C<gzip>. This
is determined using the file extension.

=head2 parse

The L</"parse"> method will either parse the file contents into a
L<Mojo::Collection> of L<FastaRecord|/"RECORDS">, or call the supplied callback
once per FASTA entry. In the case of the callback, the arguments are the C<$hdr>
and the C<$sequence>.

Usually called by L<Mojo::File::Role::Ingest/"ingest"> and in addition to the
available options understood there, Mojo::File::Role::Fasta uses the following
keys.

=over 4

=item emitter

  # A Mojo::EventEmitter
  $obj->parse({
    emitter => Mojo::EventEmitter->new->tap(on => parse_error =>
      sub ($e, $msg) {
        say STDERR "Read error: $msg";
      })
  });

The events are detailed in L</"EVENTS">. The default emitter will
L<warn|perlfunc/"warn"> on L</"parse_error">.

=back

=head1 RECORDS

The C<FastaRecord> returned in the collection are
L<readonly structs|Struct::Dumb/"readonly_struct"> with the following attributes.

=head2 id

This is the header line of the record.

=head2 seq

This is the sequence of the record.

=cut
