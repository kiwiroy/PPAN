package Mojo::File::Role::Ingest;

use Mojo::Base -role, -signatures;
use Mojo::File 'path';
use constant MAX_MEMORY => $ENV{MOJO_MAX_MEMORY_SIZE} || 262144;

our $VERSION = '0.01';

sub ingest {
  my ($self, $class, $opts) = (shift, shift, shift || {});
  return unless defined $class;
  return unless -r $self && !-d _;
  return if $class =~ /[+:]IngestI?$/;
  return
    unless my $composed
    = eval { path(${$self})->with_roles($class, '+IngestI') };
  $opts->{is_large} = !!((-s ${$self}) > MAX_MEMORY);
  $opts->{eol}      //= $/;
  $opts->{encoding} //= 'UTF-8';
  $opts->{mode}     //= sprintf '<:encoding(%s)' => $opts->{encoding};
  return $composed->parse($opts, @_);
}

1;

=encoding utf8

=head1 NAME

Mojo::File::Role::Ingest - Add ingest method to a file.

=head1 SYNOPSIS

  $file = path('file.txt')->with_roles('+Ingest');
  # Mojo::Collection
  $lines = $file->ingest('Mojo::File::Role::Lines');

  @lines;
  $file->ingest('+Lines', {}, sub { push @lines, $_ unless m/^#/ });

  $ext_to_role = {csv => '+CSV', txt => '+Lines'};
  $file->list->each(sub {
    $_->ingest()
  })

=head1 DESCRIPTION

=head1 METHODS

Mojo::File::Role::Ingest composes the following methods.

=head2 ingest

  # Mojo::Collection of lines
  $lines = $file->ingest('+Lines');
  # same, but change the end of line ($INPUT_RECORD_SEPARATOR)
  $lines = $file->ingest('+Lines', {eol => "//\n"});
  # use a callback to collect lines
  @lines;
  $file->ingest('+Lines', {}, sub { push @lines, $_ unless m/^#/ });

L</"ingest"> delegates to the supplied L<role's|Role::Tiny> C<parse> method. See
L<Mojo::File::Role::IngestI> for more info on the interface.

=head1 SEE ALSO

=over 4

=item L<Mojo::File>

=item L<Mojo::File::Role::IngestI>

=item L<https://github.com/mojolicious/mojo/issues/1392>

=back

=cut
